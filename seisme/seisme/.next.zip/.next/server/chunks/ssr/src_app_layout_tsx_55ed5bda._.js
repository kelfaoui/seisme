module.exports = {

"[project]/src/app/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_layout_tsx_55ed5bda._.js.map