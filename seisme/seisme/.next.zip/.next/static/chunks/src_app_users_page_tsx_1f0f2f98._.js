(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_6d4e8d45._.js",
  "static/chunks/node_modules_342e8a94._.js",
  "static/chunks/src_app_5da95424._.js",
  "static/chunks/node_modules_@fortawesome_fontawesome-svg-core_styles_e26fa617.css"
],
    source: "dynamic"
});
