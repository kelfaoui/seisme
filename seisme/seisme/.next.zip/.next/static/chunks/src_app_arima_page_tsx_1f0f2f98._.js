(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_20634561._.js",
  "static/chunks/node_modules_recharts_es6_6a3f2090._.js",
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_6d4e8d45._.js",
  "static/chunks/node_modules_868f2893._.js",
  "static/chunks/src_app_cbebf46b._.js",
  "static/chunks/node_modules_@fortawesome_fontawesome-svg-core_styles_e26fa617.css"
],
    source: "dynamic"
});
