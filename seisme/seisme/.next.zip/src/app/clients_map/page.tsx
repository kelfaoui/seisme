'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Layout from '../components/Layout';

const Map = dynamic(() => import('react-leaflet').then(mod => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then(mod => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then(mod => mod.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then(mod => mod.Popup), { ssr: false });

const cityCoordinates: Record<string, [number, number]> = {
  "Alger": [36.75, 3.06],
  "Oran": [35.6971, -0.6308],
  "Tizi Ouzou": [36.7169, 4.0497],
  "Blida": [36.4700, 2.8289],
  "Biskra": [34.85, 5.73],
  "Batna": [35.55, 6.17],
  "Sétif": [36.18, 5.41],
  "Annaba": [36.9, 7.766],
  "Constantine": [36.365, 6.6147],
  "Mostaganem": [35.93, 0.09],
  "Béjaïa": [36.75, 5.07],
  "Skikda": [36.86, 6.91],
  "Tamanrasset": [22.79, 5.52],
};

const generateSvgIcon = (color: string) => {
  const svgString = `
    <svg xmlns='http://www.w3.org/2000/svg' width='32' height='48' viewBox='0 0 24 36'>
      <path d='M12 0C7.03 0 3 4.03 3 9c0 6.63 9 18 9 18s9-11.37 9-18c0-4.97-4.03-9-9-9z' fill='${color}' stroke='black' stroke-width='1'/>
      <circle cx='12' cy='9' r='3' fill='white'/>
    </svg>
  `;
  return L.divIcon({
    html: svgString,
    className: '',
    iconSize: [32, 48],
    iconAnchor: [16, 48],
    popupAnchor: [0, -44],
  });
};

const getRandomColor = () => `hsl(${Math.floor(Math.random() * 360)}, 70%, 50%)`;

const getJitteredPosition = ([lat, lng]: [number, number]): [number, number] => {
  const jitter = () => (Math.random() - 0.9) * 0.7;
  return [lat + jitter(), lng + jitter()];
};

export default function ClientMapPage() {
  const [clients, setClients] = useState<any[]>([]);

  useEffect(() => {
    const fetchClients = async () => {
      const res = await fetch(`/api/maps`);
      const data = await res.json();
      setClients(data);
    };
    fetchClients();
  }, []);

  return (
    <Layout>
      <div className="container mx-auto py-6">
        <h1 className="text-xl font-bold mb-4">Carte des Clients</h1>
        <div className="h-[600px] w-full rounded-lg overflow-hidden">
          <Map center={[36.75, 3.06]} zoom={6} scrollWheelZoom={true} style={{ height: '100%', width: '100%' }}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a> contributors"
            />
            {clients.map(client => {
              const baseCoords = cityCoordinates[client.localisation];
              if (!baseCoords) return null;
              const coords = getJitteredPosition(baseCoords);
              const icon = generateSvgIcon(getRandomColor());
              return (
                <Marker key={client.client_id} position={coords} icon={icon}>
                  <Popup>
                    <div className="text-sm space-y-2">
                      <div>
                        <strong>{client.nom_complet}</strong><br />
                        {client.email}<br />
                        {client.localisation} — {client.age} ans
                      </div>

                      <div className="flex gap-2">
                        <a
                          href={`/arima?client_id=${client.client_id}`}
                          className="bg-purple-100 px-3 py-1 rounded text-xs hover:bg-purple-600 text-white hover:text-white"
                        >
                          ARIMA
                        </a>
                        <a
                          href={`/lstm?client_id=${client.client_id}`}
                          className="bg-purple-100 px-3 py-1 rounded text-xs hover:bg-purple-600 text-white hover:text-white"
                        >
                          LSTM
                        </a>
                      </div>
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </Map>
        </div>
      </div>
    </Layout>
  );
}
