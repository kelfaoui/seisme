'use client';

import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

interface Client {
  client_id: number;
  genre?: 'M' | 'F' | 'Autre';
  age?: number;
  nom_complet?: string;
  localisation?: string;
  date_inscription: string;
  email?: string;
}

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const limit = 10;

  useEffect(() => {
    fetch(`/api/clients?page=${page}`)
      .then(res => res.json())
      .then(data => {
        setClients(data.data);
        setTotal(data.total);
      });
  }, [page]);

  const totalPages = Math.ceil(total / limit);

  const handleEdit = (id: number) => {
    console.log('Edit client with ID:', id);
    // Redirect to edit page or open modal here
  };

  const handleDelete = (id: number) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce client ?')) {
      fetch(`/api/clients/${id}`, { method: 'DELETE' }).then(() => {
        setClients(clients.filter(c => c.client_id !== id));
      });
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold">Clients</h1>
          <button
            onClick={() => console.log('Add new client')}
            className="bg-purple-500 hover:bg-purple-700 text-white text-sm font-medium px-3 py-1 rounded-lg shadow"
          >
            + Nouveau Client
          </button>
        </div>

        <div className="overflow-x-auto rounded-xl shadow-md bg-white">
          <table className="w-full text-sm text-left text-gray-700">
            <thead className="bg-gray-100 text-gray-700 uppercase text-xs">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Genre</th>
                <th className="px-4 py-3">Nom complet</th>
                <th className="px-4 py-3">Âge</th>
                <th className="px-4 py-3">Localisation</th>
                <th className="px-4 py-3">Email</th>
               
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c, idx) => (
                <tr key={c.client_id} className={`hover:bg-gray-50 ${idx % 2 === 1 ? 'bg-gray-50' : 'bg-white'}`}>
                  <td className="px-4 py-2">{c.client_id}</td>
                  <td className="px-4 py-2">{c.genre || '-'}</td>
                  <td className="px-4 py-2">{c.nom_complet || '-'}</td>
                  <td className="px-4 py-2">{c.age ?? '-'}</td>
                  <td className="px-4 py-2">{c.localisation || '-'}</td>
                  <td className="px-4 py-2">{c.email || '-'}</td>
                 
                  <td className="px-4 py-2 space-x-2">
                    <button
                      onClick={() => handleEdit(c.client_id)}
                      className="text-white hover:underline text-xs bg-purple-500 px-2 py-1 rounded"
                    >
                      Modifier <FontAwesomeIcon icon={faEdit} />
                    </button>
                    <button
                      onClick={() => handleDelete(c.client_id)}
                      className="text-white hover:underline text-xs bg-purple-500 px-2 py-1 rounded"
                    >
                      Supprimer <FontAwesomeIcon icon={faTrashAlt} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Compact Pagination */}
        <div className="flex justify-center items-center gap-1 mt-6 text-sm">
          <button
            onClick={() => setPage(1)}
            disabled={page === 1}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            «
          </button>

          <button
            onClick={() => setPage(p => Math.max(p - 1, 1))}
            disabled={page === 1}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            ‹
          </button>

          {page > 2 && <span className="w-8 text-center">…</span>}

          {page > 1 && (
            <button
              onClick={() => setPage(page - 1)}
              className="w-8 h-8 border border-gray-300 rounded"
            >
              {page - 1}
            </button>
          )}

          <span className="w-8 h-8 flex items-center justify-center bg-purple-500 text-white rounded border border-gray-300">
            {page}
          </span>

          {page < totalPages && (
            <button
              onClick={() => setPage(page + 1)}
              className="w-8 h-8 border border-gray-300 rounded"
            >
              {page + 1}
            </button>
          )}

          {page < totalPages - 1 && <span className="w-8 text-center">…</span>}

          <button
            onClick={() => setPage(p => Math.min(p + 1, totalPages))}
            disabled={page === totalPages}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            ›
          </button>

          <button
            onClick={() => setPage(totalPages)}
            disabled={page === totalPages}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            »
          </button>
        </div>

      </div>
    </Layout>
  );
}
