import Layout from './components/Layout';

export default function ClientsPage() {
  return (
    <Layout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Clients</h1>
        {/* Page content here */}
      </div>
    </Layout>
  );
}