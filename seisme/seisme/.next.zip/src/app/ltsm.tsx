import Layout from './components/Layout';

export default function LTSMPage() {
  return (
    <Layout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">LTSM</h1>
        {/* Page content here */}
      </div>
    </Layout>
  );
}