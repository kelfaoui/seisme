'use client';

import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEarDeaf, faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

interface Product {
  produit_id: number;
  categorie_id?: number;
  prix: number;
  stock: number;
  date_ajout: string;
  nom: string;
  image_path?: string;
  description?: string;
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const limit = 10;

  useEffect(() => {
    fetch(`/api/products?page=${page}`)
      .then(res => res.json())
      .then(data => {
        setProducts(data.data);
        setTotal(data.total);
      });
  }, [page]);

  const totalPages = Math.ceil(total / limit);

  const handleEdit = (id: number) => {
    console.log('Edit produit with ID:', id);
    // You can redirect to an edit page or open a modal here
  };

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this produit?')) {
      fetch(`/api/products/${id}`, {
        method: 'DELETE',
      }).then(() => {
        setProducts(products.filter(p => p.produit_id !== id));
      });
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold">Produits</h1>
          <button
            onClick={() => console.log('Add new produit')}
            className="bg-purple-500 hover:bg-purple-700 text-white text-sm font-medium px-3 py-1 rounded-lg shadow"
          >
            + Nouveau Produit
          </button>
        </div>

        <div className="overflow-x-auto rounded-xl shadow-md bg-white">
          <table className="w-full text-sm text-left text-gray-700">
            <thead className="bg-gray-100 sticky top-0 text-gray-700 uppercase text-xs">
              <tr>
                <th className="px-4 py-3">ID</th>
                <th className="px-4 py-3">Image</th>
                <th className="px-4 py-3">Nom</th>
                <th className="px-4 py-3">Prix</th>
                <th className="px-4 py-3">Stock</th>
                <th className="px-4 py-3">Date d'ajout</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p, idx) => (
                <tr
                  key={p.produit_id}
                  className={`hover:bg-gray-50 ${idx % 2 === 1 ? 'bg-gray-50' : 'bg-white'}`}
                >
                  <td className="px-4 py-0">{p.produit_id}</td>
                  <td className="px-4 py-0">
                    <img
                      src={p.image_path || '/default-image.png'}
                      alt={p.nom}
                      className="w-10 h-10 object-cover rounded"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/default-image.png';
                      }}
                    />
                  </td>
                  <td className="px-4 py-0">{p.nom}</td>
                  <td className="px-4 py-0">€{Number(p.prix).toFixed(2)}</td>
                  <td className="px-4 py-0">{p.stock}</td>
                  <td className="px-4 py-0">{new Date(p.date_ajout).toLocaleString()}</td>
                  <td className="px-4 py-2 space-x-2">
                    <button
                      onClick={() => handleEdit(p.produit_id)}
                      className="text-white hover:underline text-xs bg-purple-500 px-2 py-1 rounded"
                    >
                      Modifier <FontAwesomeIcon icon={faEdit} />
                    </button>
                    <button
                      onClick={() => handleDelete(p.produit_id)}
                      className="text-white hover:underline text-xs bg-purple-500 px-2 py-1 rounded"
                    >
                      Supprimer <FontAwesomeIcon icon={faTrashAlt} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

                {/* Compact Pagination */}
                <div className="flex justify-center items-center gap-1 mt-6 text-sm">
          <button
            onClick={() => setPage(1)}
            disabled={page === 1}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            «
          </button>

          <button
            onClick={() => setPage(p => Math.max(p - 1, 1))}
            disabled={page === 1}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            ‹
          </button>

          {page > 2 && <span className="w-8 text-center">…</span>}

          {page > 1 && (
            <button
              onClick={() => setPage(page - 1)}
              className="w-8 h-8 border border-gray-300 rounded"
            >
              {page - 1}
            </button>
          )}

          <span className="w-8 h-8 flex items-center justify-center bg-purple-500 text-white rounded border border-gray-300">
            {page}
          </span>

          {page < totalPages && (
            <button
              onClick={() => setPage(page + 1)}
              className="w-8 h-8 border border-gray-300 rounded"
            >
              {page + 1}
            </button>
          )}

          {page < totalPages - 1 && <span className="w-8 text-center">…</span>}

          <button
            onClick={() => setPage(p => Math.min(p + 1, totalPages))}
            disabled={page === totalPages}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            ›
          </button>

          <button
            onClick={() => setPage(totalPages)}
            disabled={page === totalPages}
            className="w-8 h-8 border border-gray-300 rounded disabled:opacity-40"
          >
            »
          </button>
        </div>
      </div>
    </Layout>
  );
}
