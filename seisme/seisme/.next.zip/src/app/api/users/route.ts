// app/api/users/route.ts
import { NextResponse } from 'next/server';
import { db } from '@/lib/db'; // make sure this exports a MySQL pool or connection

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const page = parseInt(searchParams.get('page') || '1', 10);
  const limit = 10;
  const offset = (page - 1) * limit;

  const [users] = await db.query('SELECT * FROM users LIMIT ? OFFSET ?', [limit, offset]);
  const [result] = await db.query('SELECT COUNT(*) as total FROM users');
  const total = (result as any)[0].total;

  return NextResponse.json({ data: users, total });
}
